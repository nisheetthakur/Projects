const mongoCollection = require("../dbConfig/mongoCollection");
const users = mongoCollection.users;
const uuid = require('node-uuid');

module.exports = {
    async getUserById(id) {
        if (!id) throw "You must provide an id to search for";
    
        const userCollection = await users();
        const userGo = await userCollection.findOne({ _id: id });
        if (userGo === null) throw "No user with that id";
    
        return userGo;
      },

      async getUserByFirstName(firstName) {
        if (!firstName) throw "You must provide a name to search for";
    
        const userCollection = await users();
        const userGo = await userCollection.findOne({ _firstName: firstName });
        if (userGo === null) throw "No user with that name";
    
        return userGo;
      },
      async getAllUsers() {
        const userCollection = await users();
    
        const usersFinder = await userCollection.find({}).toArray();
    
        return usersFinder;
      },
    
      async addUser(firstName, lastName, gender, email, team) {
        if(!firstName)throw"No was provided";
        if(!lastName)throw"No was provided";
        if(!gender)throw"No was provided";
        if(!email)throw"No was provided";
        const userCollection = await users();
    
        let newUser = {
          firstName: firstName,
          lastName: lastName,
          _id: uuid.v4(),
          gender: gender,
          email: email,
          team:team
        };
        console.log(newUser);
        const insertInfo = await userCollection.insertOne(newUser);
        if (insertInfo.insertedCount === 0) throw "Could not add user";
    
        const newId = insertInfo.insertedId;
    
        const user = await this.getUserById(newId);
        return user;
      },
      async removeUser(id) {
        if (!id) throw "You must provide an id to search for";
    
        const userCollection = await users();
        const deletionInfo = await userCollection.removeOne({ _id: id });
    
        if (deletionInfo.deletedCount === 0) {
          throw `Could not delete user with id of ${id}`;
        }
      },
      async updateuser(id, firstName, lastName, gender, email, team) {
        if(!firstName)throw"No was provided";
        if(!lastName)throw"No was provided";
        if(!gender)throw"No was provided";
        if(!email)throw"No was provided";
        if (!id) throw "You must provide an id to search for";
 
        const userCollection = await users();
        let updatedUser = {
          firstName: firstName,
          lastName: lastName,
          gender: gender,
          email: email,
          team: team
        };
    
        const updatedInfo = await userCollection.updateOne({ _id: id }, updatedUser);
        if (updatedInfo.modifiedCount === 0) {
          throw "could not update user successfully";
        }
    
        return await this.getUserById(id);
      },



};