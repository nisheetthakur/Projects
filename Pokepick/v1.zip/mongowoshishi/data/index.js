const userData = require('./user');
module.exports = {
    user: userData
}