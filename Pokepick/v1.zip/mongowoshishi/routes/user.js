const express = require('express');
const router = express.Router();
const data = require("../data");
const userData  = data.user;

router.get('/', async(req, res) => {
    try{
        const getAllUsers = await userData.getAllUsers();
        res.json(getAllUsers);
    }catch(error){
        res.status(500).json({error: error});
    }
})
router.get('/:firstName', async(req, res) => {
    try{
        const getUserByFirstName = await userData.getUserByFirstName(req.params.firstName);
        res.json(getUserByFirstName);
    }catch(error){
        res.status(404).json({error: "User not found!"});
    }
})

router.get('/:id', async(req, res) => {
    try{
        const getUserById = await userData.getUserById(req.params.id);
        res.json(getUserById);
    }catch(error){
        res.status(404).json({error: "User not found!"});
    }
})

router.post("/", async(req, res) => {
    const info = req.body;
    try{
        const addUser = await userData.addUser(info.firstName, info.lastName, info.gender, info.email, info.team);
        res.status(200).json({success:"add user successfully"});
    }catch(error){
        res.status(500).json({error: "Could not add user"});
    }
})

router.put('/:id', async (req, res) => {
    try{
        const updateUser = await userData.updateUser(req.params.id, req.params.firstName, req.params.lastName, req.params.gender, req.params.email, req.params.team);
        res.status(200).json({success:"You have been updated "});
    }catch(error){
        res.status(404).json({error: "cannot found user"});
    }
})

router.delete('/:id', async (req, res) => {
    try{
        const removeUser = await userData.removeUser(id);
    }catch(error){
        res.status(404).json({error: "cannot found user"});
    }
})
module.exports = router;