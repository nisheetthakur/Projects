const express = require('express');
const app = express();
const bodyParser = require("body-parser");
const routeConfig = require('./routes');


app.use(bodyParser.urlencoded());
app.use(bodyParser.json());

routeConfig(app);

app.listen(3000, (req, res) => {
    console.log("Sever is running on => http://localhost:3000");
})

